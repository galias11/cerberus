$(document).ready(function () {
    $("#id_busqueda").val('');
});


$(".int-right").hover(function () {
    $(this).animate({ "left": "81%" });
});

$(".int-right").mouseleave(function () {
    $(this).animate({ "left": "83%" });
});

$(".int-left").hover(function () {
    $(this).animate({ "left": "1.8rem" });
});

$(".int-left").mouseleave(function () {
    $(this).animate({ "left": "1.5rem" });
});

$(".fa-brain").hover(function () {
    $(this).animate({ fontSize: "29px" });
});

$(".fa-brain").mouseleave(function () {
    $(this).animate({ fontSize: "15px" });
});

$(".fa-compass").hover(function () {
    $(this).animate({ fontSize: "32px" });
});

$(".fa-compass").mouseleave(function () {
    $(this).animate({ fontSize: "17px" });
});

$(".fa-search").hover(function () {
    $(this).animate({ fontSize: "29px" });
});

$(".fa-search").mouseleave(function () {
    $(this).animate({ fontSize: "15px" });
});

