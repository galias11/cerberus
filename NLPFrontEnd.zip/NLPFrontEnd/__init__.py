"""
Package for NLPFrontEnd.
"""
