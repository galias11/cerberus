import json
import spacy

nlp_path = "es_core_news_sm"
nlp = spacy.load(nlp_path)

def generarJson(doc):
    entidades = {}
    entidades["tokens"] = [token.string for token in doc]
    entidades["entities"] = [(entidad.string,entidad.label_,entidad.start,entidad.end) for entidad in doc.ents]

    return json.dumps(entidades)

def get_nlp():
    return nlp

def get_nlp_version():
    return nlp_path

#def entidadPersona(entidades,doc,entidades_dic):
#    d_res = defaultdict(list)
            
                
#    for entidad in entidades:
#        if entidad.tipo == entidades_dic["pers"]:
#            d_res[doc.nombre_doc].append((doc.id,,resultado[4]))
