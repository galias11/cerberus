from django.apps import AppConfig


class FrontEndConfig(AppConfig):
    name = 'FrontEnd'
